"use strict";

function Home() {
    return (
        <div className="home">
            <p>
                This website will allow you to create a list of books that you are planning
                to read. As well as show off your books progression in their readings. If you
                are willing to add a book that you authored, they can also make progression
                and notes on their public progress. You are able to rate the books in your
                choosing to inspire others to do the same!
            </p>
        </div>
    );
}