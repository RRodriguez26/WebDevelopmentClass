package com.rodriguez_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RodriguezWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(RodriguezWebApplication.class, args);
	}

}
