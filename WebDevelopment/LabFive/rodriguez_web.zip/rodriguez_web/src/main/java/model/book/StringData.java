package model.book;

public class StringData {
    public String bookId = ""; 
    public String bookReviewId = "";
    public String webUserId = "";
    public String errorMsg = "";
}
