function CarsComingSoon() {

  var ele = document.createElement("div");
  ele.innerHTML = `
    <div class="cars">
      <h3>Car Info Coming Soon</h3>
      <p>This page is under construction. Check back soon for updates!</p>
    </div>
  `;
  return ele;
}