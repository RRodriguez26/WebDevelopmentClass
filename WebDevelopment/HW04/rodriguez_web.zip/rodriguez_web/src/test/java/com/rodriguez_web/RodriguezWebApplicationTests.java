package com.rodriguez_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RodriguezWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
