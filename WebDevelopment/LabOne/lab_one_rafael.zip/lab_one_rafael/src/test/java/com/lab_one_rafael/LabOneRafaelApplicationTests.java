package com.lab_one_rafael;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabOneRafaelApplicationTests {

	@Test
	void contextLoads() {
	}

}
