function Blog() {
    return (
        <div className="blog">
            <h4>Sample Blog Entry</h4>
            <p>
                Hey guys -- the Blog Component works !
            </p>
        </div>
    );
}