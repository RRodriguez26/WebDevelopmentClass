function UsersComingSoon() {
  return (
    <div className="comingSoon">
      <h3>Users Coming Soon</h3>
      <p>Our user page is under construction. Check back soon for updates!</p>
    </div>
  );
}
